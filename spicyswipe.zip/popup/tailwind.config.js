module.exports = {
  darkMode: 'class',
  content: [
    './popup/*.html',
    './popup/*.js',
    '../friend/*.html',
    '../friend/*.js'
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}; 